create definer = root@`%` view v_category1 as
select `tc`.`id` AS `id`, `tc`.`name` AS `name`
from `qingcheng_goods`.`tb_category` `tc`
where (`tc`.`parent_id` = 0);

-- comment on column v_category1.id not supported: 分类ID

-- comment on column v_category1.name not supported: 分类名称

